package bad

type Emb struct {
	Bad bool `json:"bad"`
} // @name Emb
