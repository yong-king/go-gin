package api

// RandomFunc dogoc
// @Description.markdown api
// @Success 200 {string} string	"ok"
// @Router /random [get]
func RandomFunc() {}
