package main

// @title Swagger Example API
// @version 1.0
// @description test data for deprecated router
// @termsOfService http://swagger.io/terms/

func main() {
}
